-- was fixed retroactively in 0010, repeat here
ALTER TABLE TABLE_PREFIXcarddav_addressbooks ALTER COLUMN sync_token SET DEFAULT '';
