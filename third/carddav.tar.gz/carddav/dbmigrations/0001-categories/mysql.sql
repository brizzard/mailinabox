ALTER TABLE TABLE_PREFIXcarddav_addressbooks ADD `use_categories` INT NOT NULL DEFAULT '0' AFTER `presetname`;
