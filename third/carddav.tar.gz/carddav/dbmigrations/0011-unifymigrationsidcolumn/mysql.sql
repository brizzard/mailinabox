ALTER TABLE TABLE_PREFIXcarddav_migrations CHANGE `ID` `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
