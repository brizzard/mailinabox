SELECT * FROM TABLE_PREFIXcarddav_migrations; -- No migration
