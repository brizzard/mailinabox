SELECT * FROM TABLE_PREFIXcarddav_migrations; -- Just an example migration.
